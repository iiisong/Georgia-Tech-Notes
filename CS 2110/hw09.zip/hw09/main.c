#include "list.h"

#include <stdio.h>

int main(void) {
    printf("Test\n");
}

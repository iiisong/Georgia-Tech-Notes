arrow keys to move around 2d plane
hold z to move by 1 pixel when tap
enter to start from initial screen
backspace to reset

objective: move the piece of the painting to the correct spot in the full painting without touching the sunflowers before the timer runs out
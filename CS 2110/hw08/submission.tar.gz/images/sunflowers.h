/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 sunflowers sunflowers.jpg 
 * Time-stamp: Wednesday 04/05/2023, 03:46:05
 * 
 * Image Information
 * -----------------
 * sunflowers.jpg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SUNFLOWERS_H
#define SUNFLOWERS_H

extern const unsigned short sunflowers[900];
#define SUNFLOWERS_SIZE 1800
#define SUNFLOWERS_LENGTH 900
#define SUNFLOWERS_WIDTH 30
#define SUNFLOWERS_HEIGHT 30

#endif


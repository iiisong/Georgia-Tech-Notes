/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 irises irises.jpg 
 * Time-stamp: Wednesday 04/05/2023, 03:49:17
 * 
 * Image Information
 * -----------------
 * irises.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IRISES_H
#define IRISES_H

extern const unsigned short irises[38400];
#define IRISES_SIZE 76800
#define IRISES_LENGTH 38400
#define IRISES_WIDTH 240
#define IRISES_HEIGHT 160

#endif


/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 starrynight starry_night.jpg 
 * Time-stamp: Wednesday 04/05/2023, 00:51:18
 * 
 * Image Information
 * -----------------
 * starry_night.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARRYNIGHT_H
#define STARRYNIGHT_H

extern const unsigned short starry_night[38400];
#define STARRY_NIGHT_SIZE 76800
#define STARRY_NIGHT_LENGTH 38400
#define STARRY_NIGHT_WIDTH 240
#define STARRY_NIGHT_HEIGHT 160

#endif


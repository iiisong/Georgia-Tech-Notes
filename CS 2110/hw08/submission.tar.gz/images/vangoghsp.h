/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x70 vangoghsp vgsp.jpg 
 * Time-stamp: Wednesday 04/05/2023, 01:28:12
 * 
 * Image Information
 * -----------------
 * vgsp.jpg 50@70
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VANGOGHSP_H
#define VANGOGHSP_H

extern const unsigned short vgsp[3500];
#define VGSP_SIZE 7000
#define VGSP_LENGTH 3500
#define VGSP_WIDTH 50
#define VGSP_HEIGHT 70

#endif


/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=50x37 garbage garbage.png 
 * Time-stamp: Sunday 03/25/2018, 11:45:04
 * 
 * Image Information
 * -----------------
 * garbage.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GARBAGE_H
#define GARBAGE_H

extern const unsigned short garbage[1850];
#define GARBAGE_SIZE 3700
#define GARBAGE_LENGTH 1850
#define GARBAGE_WIDTH 50
#define GARBAGE_HEIGHT 37

#endif


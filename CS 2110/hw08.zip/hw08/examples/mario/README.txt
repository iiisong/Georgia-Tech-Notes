Rescue Princess Peach

How the game works:
- This purpose of this game is for the player (mario) to reach princess peach.
- If mario collides with a goomba, the player loses.
- Additionally, the player's score decreases over time.
- If the score reaches 0, the player loses.
- If mario colides with princess peach, the player wins.

How to play:
- Click enter to start the game from the welcome screen
- use the arrows to move mario in any direction
- Click backspace to restart the game at any time

To run this game:
- download the zip file
- navigate into folder hw08 in terminal in docker
- run command ->  make mgba
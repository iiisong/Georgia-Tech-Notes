public class ThinCrust extends Pizza {
    public ThinCrust() { desc = "Thin crust pizza with tomato sauce"; }

    @Override
    public double cost() { return 7.99; }
}

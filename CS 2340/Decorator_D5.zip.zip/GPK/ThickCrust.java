public class ThickCrust extends Pizza {
    public ThickCrust() { desc = "Thick crust pizza with tomato sauce"; }

    @Override
    public double cost() { return 7.99; }
}
